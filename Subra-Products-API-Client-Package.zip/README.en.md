# Subra Products API

[Български](README.md)

This package contains a ready-made Postman project for the public Subra product API.

## Contents

- `README.md`
- `README.en.md`
- `Subra-Products-API.postman_collection.json`
- `Subra-Products-API.postman_environment.json`

## Setup

1. Import the collection file into Postman.
2. Import the environment file.
3. Select the `Subra API Environment` environment.
4. Fill in:
   - `catalog_token`
   - `main_api_token`

The defaults are:

- `https://id.subra.bg/categories` for categories
- `https://api.subra.bg` for the main API

## Recommended flow

### 1. Get Categories

Request:

- `1. Get Categories`

Returns a list of categories:

```json
[
  { "id": 3, "name": "Болкоуспокояващи" },
  { "id": 35, "name": "Витамини и минерали" }
]
```

Category names in the live catalog are returned in Bulgarian.

After the request runs, Postman stores:

- `category_id`
- `category_name`

### 2. Get Category By Id

Request:

- `2. Get Category By Id`

Uses the current `category_id` and returns that category.

### 3. List Products

Request:

- `3. List Products`

Supported query parameters:

- `limit`
- `offset`

Example:

- `GET /products?limit=20&offset=0`

### 4. Create Product With Full Payload

Request:

- `4. Create Product With Full Payload`

Uses the `category_id` saved by the previous step.

## Fields supported by `POST /api/v1/products`

These fields are present in the sample payload of the Postman collection:

| Field | Type | Example |
|---|---|---|
| `title` | string | `Тестов продукт от Postman` |
| `categoryId` | integer \| null | `35` |
| `currencyId` | integer \| null | `1` |
| `price` | string \| null | `"12.50"` |
| `oldPrice` | string \| null | `"14.90"` |
| `quantity` | integer \| null | `5` |
| `visibility` | integer \| null | `1` |
| `inPromotion` | boolean | `false` |
| `isNew` | boolean | `true` |
| `isBestseller` | boolean \| null | `false` |
| `isByPrescription` | boolean \| null | `false` |
| `barcode` | string \| null | `"3800123456789"` |
| `babh` | string \| null | `"BG202600123"` |
| `slug` | string \| null | `"testov-produkt-ot-postman"` |
| `text` | string \| null | `"Кратко описание на продукта."` |
| `leaflet` | string \| null | `"Информация за прием и съхранение."` |
| `searchWords` | string \| null | `"продукт тест postman"` |
| `metaTitle` | string \| null | `"Тестов продукт"` |
| `metaKeywords` | string \| null | `"тестов продукт, postman, api"` |
| `metaDescription` | string \| null | `"Примерен продукт, създаден през API."` |
| `i18nForeignKey` | integer \| null | `1001` |
| `i18nLocale` | string \| null | `"bg-BG"` |
| `itemWeight` | number \| null | `0.250` |
| `itemHeight` | number \| null | `12.5` |
| `itemWidth` | number \| null | `4.2` |
| `itemLength` | number \| null | `4.2` |
| `itemVolume` | number \| null | `0.15` |
| `itemWeightUnit` | string \| null | `"kg"` |
| `itemVolumeUnit` | string \| null | `"l"` |
| `activationDate` | ISO 8601 datetime \| null | `"2026-03-24T10:00:00+00:00"` |
| `createdAt` | ISO 8601 datetime \| null | `"2026-03-24T10:00:00+00:00"` |
| `updatedAt` | ISO 8601 datetime \| null | `"2026-03-24T10:00:00+00:00"` |
| `image1` | URL \| null | `"https://example.com/product-1.jpg"` |
| `image2` | URL \| null | `"https://example.com/product-2.jpg"` |
| `image3` | URL \| null | `"https://example.com/product-3.jpg"` |
| `image4` | URL \| null | `"https://example.com/product-4.jpg"` |
| `image5` | URL \| null | `"https://example.com/product-5.jpg"` |

Notes:

- `categoryId` must come from `GET /categories`
- images are sent as URLs
- `submittedBy` and `status` are set by the system

## Example request body

```json
{
  "title": "Тестов продукт от Postman",
  "categoryId": 35,
  "currencyId": 1,
  "price": "12.50",
  "oldPrice": "14.90",
  "quantity": 5,
  "visibility": 1,
  "barcode": "3800123456789",
  "babh": "BG202600123",
  "slug": "testov-produkt-ot-postman",
  "text": "Кратко описание на продукта.",
  "leaflet": "Информация за прием и съхранение.",
  "searchWords": "продукт тест postman",
  "metaTitle": "Тестов продукт",
  "metaKeywords": "тестов продукт, postman, api",
  "metaDescription": "Примерен продукт, създаден през API.",
  "i18nForeignKey": 1001,
  "i18nLocale": "bg-BG",
  "itemWeight": 0.250,
  "itemHeight": 12.5,
  "itemWidth": 4.2,
  "itemLength": 4.2,
  "itemVolume": 0.15,
  "itemWeightUnit": "kg",
  "itemVolumeUnit": "l",
  "isNew": true,
  "isBestseller": false,
  "isByPrescription": false,
  "inPromotion": false,
  "activationDate": "2026-03-24T10:00:00+00:00",
  "createdAt": "2026-03-24T10:00:00+00:00",
  "updatedAt": "2026-03-24T10:00:00+00:00",
  "image1": "https://example.com/product-1.jpg",
  "image2": "https://example.com/product-2.jpg",
  "image3": "https://example.com/product-3.jpg",
  "image4": "https://example.com/product-4.jpg",
  "image5": "https://example.com/product-5.jpg"
}
```

## Negative test

Request:

- `5. Negative Test - Invalid Category`

Expected result:

- `400 Bad Request`

Example:

```json
{
  "error": {
    "detail": "Invalid categoryId \"999999999\". Use GET /categories to fetch a valid category id."
  }
}
```

## Requests in the collection

- `1. Get Categories`
- `2. Get Category By Id`
- `3. List Products`
- `4. Create Product With Full Payload`
- `5. Negative Test - Invalid Category`

## Support

For more integration examples or extended documentation, contact the Subra team.
